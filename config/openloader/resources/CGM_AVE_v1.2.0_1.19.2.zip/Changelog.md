# Changelog (1.19.2 Releases)


### 1.2.0 (11/27/23)
* The models used for the Shotgun and Medium Scope are now respectively used for the Pump Shotgun and Chevron Scope in NZGE.
  As a result, these two items have received changes:
  -  The Shotgun's model is edited to resemble a Benelli M4 semi-automatic shotgun, aligning with its default stats.
  -  The Medium Scope now uses its original model again with a new reticle design.
* Updated the Pistol model - made its overall length a bit shorter and repositioned the front sight.
* Changed the Shotgun's sounds to match its new model.
* Changed the Rifle's fire sound, to better suit the sound of a semi-automatic rifle.
* Moved the .cgmmeta parameter tweaks for the NZGE Hunting Rifle to the recently added Bolt Action Rifle.
* Model adjustments to the Tactical Stocks.

NOTICE: The file name format has been changed to "(name)_(release number)_(game version)" to be consistent with the file name format used for NZGE.

### 1.1.1 (6/17/23)
* Updated enchanted gun fire sounds to reduce the volume of the 'laser gun' sound samples. This matches the changed made in NZGE v1.2.2.

### 1.1.0 (6/6/23)
* Updated the Long Scope remodel, which now resembles a Leupold CQBSS scope. A new sniper scope (the Ballistic Scope) is available in NZGE v1.2.0.
* Modified the silenced sound of the Sniper Rifle to better differentiate it from the normal Rifle.
* Added Simplified Chinese (zh_cn) translation, courtesy of chemlzh on github. Thanks!
* A few misc. model and sound updates.

### 1.0.0 (4/16/23)
* Initial release for 1.19.2 and the resource pack as a whole.